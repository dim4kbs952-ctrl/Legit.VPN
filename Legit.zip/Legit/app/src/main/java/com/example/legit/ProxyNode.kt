package com.example.legit

import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

data class ProxyNode(val name: String, val protocol: String, val raw: String)

object SubscriptionParser {
    private val schemes = listOf("vless", "vmess", "trojan", "ss", "hysteria2")

    /** Подписка = обычно base64 со списком ссылок по строкам. */
    fun parse(body: String): List<ProxyNode> {
        val text = if ("://" in body) body else decodeB64(body.trim())
        return text.lines().map { it.trim() }.mapNotNull(::parseLink)
    }

    private fun parseLink(line: String): ProxyNode? {
        val scheme = schemes.firstOrNull { line.startsWith("$it://") } ?: return null
        val name = if (scheme == "vmess") {
            runCatching { JSONObject(decodeB64(line.removePrefix("vmess://"))).optString("ps") }.getOrDefault("")
        } else {
            line.substringAfter('#', "").let { URLDecoder.decode(it, "UTF-8") }
        }
        return ProxyNode(name.ifBlank { scheme.uppercase() }, scheme, line)
    }

    private fun decodeB64(s: String) =
        String(Base64.decode(s, Base64.DEFAULT or Base64.URL_SAFE), Charsets.UTF_8)
}
