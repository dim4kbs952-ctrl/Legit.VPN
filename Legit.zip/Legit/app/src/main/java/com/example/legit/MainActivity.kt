package com.example.legit

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Home(vm) } }
    }
}

@Composable
fun Home(vm: MainViewModel) {
    val ctx = LocalContext.current
    fun start() {
        ctx.startService(Intent(ctx, ProxyVpnService::class.java)
            .putExtra(ProxyVpnService.EXTRA_LINK, vm.selected?.raw))
        vm.connected = true
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) start()
    }
    fun toggle() {
        if (vm.connected) {
            ctx.startService(Intent(ctx, ProxyVpnService::class.java).setAction(ProxyVpnService.ACTION_STOP))
            vm.connected = false
        } else if (vm.selected != null) {
            val i = VpnService.prepare(ctx)
            if (i != null) permission.launch(i) else start()
        }
    }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(vm.url, { vm.url = it }, Modifier.fillMaxWidth(),
                label = { Text("Ссылка на подписку") }, singleLine = true)
            Button({ vm.update() }, Modifier.fillMaxWidth()) { Text("Обновить подписку") }
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            LazyColumn(Modifier.weight(1f)) {
                items(vm.nodes) { n ->
                    ListItem(
                        headlineContent = { Text(n.name) },
                        supportingContent = { Text(n.protocol.uppercase()) },
                        trailingContent = { RadioButton(n == vm.selected, { vm.selected = n }) },
                        modifier = Modifier.clickable { vm.selected = n })
                    HorizontalDivider()
                }
            }
            Button({ toggle() }, Modifier.fillMaxWidth().height(56.dp).align(Alignment.CenterHorizontally)) {
                Text(if (vm.connected) "Отключить" else "Подключить")
            }
        }
    }
}
