package com.example.legit

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class SubscriptionRepository {
    suspend fun fetch(url: String): List<ProxyNode> = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "Legit/0.1")
        try { SubscriptionParser.parse(c.inputStream.bufferedReader().readText()) } finally { c.disconnect() }
    }
}
