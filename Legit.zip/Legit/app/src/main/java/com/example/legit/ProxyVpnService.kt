package com.example.legit

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class ProxyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stop(); return START_NOT_STICKY }
        val link = intent?.getStringExtra(EXTRA_LINK) ?: return START_NOT_STICKY
        tun = Builder()
            .setSession("Legit")
            .addAddress("10.10.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setMtu(1500)
            .establish()
        // TODO: 1) собрать конфиг Xray из `link`
        //       2) запустить ядро Xray (SOCKS на 127.0.0.1:10808)
        //       3) tun2socks: пробросить tun.fd -> SOCKS
        //       4) protect(socket) для исходящих сокетов ядра
        return START_STICKY
    }

    private fun stop() { tun?.close(); tun = null; stopSelf() }
    override fun onDestroy() { stop(); super.onDestroy() }

    companion object {
        const val ACTION_STOP = "stop"
        const val EXTRA_LINK = "link"
    }
}
