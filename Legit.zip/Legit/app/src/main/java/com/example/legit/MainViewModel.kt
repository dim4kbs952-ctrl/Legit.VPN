package com.example.legit

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val repo = SubscriptionRepository()
    var url by mutableStateOf("")
    var nodes by mutableStateOf<List<ProxyNode>>(emptyList())
    var selected by mutableStateOf<ProxyNode?>(null)
    var connected by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun update() = viewModelScope.launch {
        error = null
        runCatching { repo.fetch(url) }
            .onSuccess { nodes = it; selected = it.firstOrNull() }
            .onFailure { error = it.message }
    }
}
