# Legit (Android, Kotlin + Compose)

Готово: UI, загрузка и разбор подписок (vless/vmess/trojan/ss/hysteria2), выбор узла,
запрос VPN-разрешения, VpnService с созданием TUN.
Не готово (TODO в ProxyVpnService.kt): ядро Xray, генерация конфига из ссылки, tun2socks.

Сборка: открыть в Android Studio (Koala+), Sync, Run.
